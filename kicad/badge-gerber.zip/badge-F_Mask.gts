%TF.GenerationSoftware,KiCad,Pcbnew,10.0.6*%
%TF.CreationDate,2026-09-25T18:20:49+03:00*%
%TF.ProjectId,badge,62616467-652e-46b6-9963-61645f706362,rev?*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.6) date 2026-09-25 18:20:49*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10R,1.700000X1.700000*%
%ADD11C,1.700000*%
%ADD12RoundRect,0.250000X-0.250000X-0.475000X0.250000X-0.475000X0.250000X0.475000X-0.250000X0.475000X0*%
G04 APERTURE END LIST*
D10*
%TO.C,J1*%
X118730000Y-120000000D03*
D11*
X121270000Y-120000000D03*
%TD*%
D12*
%TO.C,R1*%
X111050000Y-113000000D03*
X112950000Y-113000000D03*
%TD*%
%TO.C,D1*%
X107050000Y-113000000D03*
X108950000Y-113000000D03*
%TD*%
%TO.C,R2*%
X127050000Y-113000000D03*
X128950000Y-113000000D03*
%TD*%
%TO.C,D2*%
X131050000Y-113000000D03*
X132950000Y-113000000D03*
%TD*%
%TO.C,R3*%
X111050000Y-127000000D03*
X112950000Y-127000000D03*
%TD*%
%TO.C,D3*%
X107050000Y-127000000D03*
X108950000Y-127000000D03*
%TD*%
%TO.C,R4*%
X127050000Y-127000000D03*
X128950000Y-127000000D03*
%TD*%
%TO.C,D4*%
X131050000Y-127000000D03*
X132950000Y-127000000D03*
%TD*%
M02*
